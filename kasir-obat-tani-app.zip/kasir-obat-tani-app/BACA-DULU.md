# Kasir Obat Tani: cara pasang

Aplikasi ini berjalan sepenuhnya di HP atau komputer kamu. Semua data (produk, harga, transaksi, bon, laporan) disimpan di perangkat itu sendiri. Tidak ada server, akun, atau langganan. Tempat menaruh file hanya dipakai untuk membagikan aplikasinya, data toko tidak pernah dikirim ke sana.

## Isi folder

- `index.html`: aplikasinya
- `manifest.webmanifest`, `sw.js`, `icons/`: supaya bisa dipasang seperti aplikasi dan jalan tanpa internet

## Cara paling mudah: taruh di internet gratis, lalu pasang

Aplikasi perlu "alamat web" sekali saja agar bisa dipasang ke layar utama. Pilih salah satu:

**A. Netlify Drop (tanpa akun, paling cepat)**
1. Buka app.netlify.com/drop
2. Seret seluruh folder ini ke halaman itu
3. Kamu dapat alamat seperti `https://nama-acak.netlify.app`. Buka alamat itu di HP.

**B. GitHub Pages**
1. Buat repositori baru di GitHub, unggah semua isi folder ini
2. Settings → Pages → pilih branch `main` → Save
3. Buka alamat `https://namamu.github.io/nama-repo/`

## Pasang di perangkat

- **Android (Chrome):** buka alamatnya, ketuk menu ⋮ → **Pasang aplikasi** (atau **Tambahkan ke layar utama**)
- **iPhone (Safari):** buka alamatnya, ketuk Bagikan → **Tambah ke Layar Utama**
- **Komputer (Chrome/Edge):** klik ikon pasang di ujung kanan kolom alamat

Setelah terpasang dan dibuka sekali, aplikasi bisa dipakai tanpa internet.

Tanpa hosting pun bisa: klik dua kali `index.html` untuk membukanya di browser komputer. Data tetap tersimpan, tapi tidak bisa dipasang sebagai aplikasi.

## Langkah pertama

1. Buka tab **Atur** → isi nama toko, alamat, telepon (muncul di struk)
2. Tab **Harga** → tambah produkmu, atau pakai "Muat produk contoh" untuk mencoba dulu
3. Atur **PIN pemilik** di tab Atur. Kasir yang tidak tahu PIN hanya bisa memakai Kasir, Label, dan Bon.
4. Mulai jualan di tab **Kasir**

## Yang bisa dilakukan

- Kasir dengan scan barcode (scanner USB, atau kamera di Chrome Android), diskon, cara bayar Tunai, Transfer, dan **Bon**
- Struk: cetak atau kirim lewat WhatsApp
- Daftar harga dengan margin, stok menipis, dan tanggal kadaluarsa; tombol **Stok masuk** untuk barang datang
- **Bon pelanggan**: catat utang petani, terima cicilan, lihat sisa
- **Laporan**: laba bersih harian dan bulanan, kerugian (rusak, kadaluarsa, hilang), pengeluaran, rekap 14 hari, produk terlaris, unduh CSV untuk Excel
- Label harga rak yang bisa dicetak

## Data tetap milikmu: backup itu wajib

Karena data hanya ada di browser perangkat, ada dua hal yang perlu kamu tahu:

1. **Menghapus data situs, memasang ulang browser, atau ganti HP akan menghapus data.** Buka tab **Atur → Unduh backup** minimal seminggu sekali (aplikasi akan mengingatkan). Simpan file `.json`-nya di Google Drive, flashdisk, atau kirim ke WhatsApp sendiri.
2. **Pindah HP atau pakai di dua perangkat:** unduh backup di perangkat lama, lalu **Pulihkan dari file** di perangkat baru. Data di dua perangkat tidak tersinkron otomatis, jadi pakai satu perangkat utama untuk kasir.

## Lupa PIN?

PIN adalah pembatas untuk kasir, bukan enkripsi. Kalau lupa PIN, buka aplikasi di browser atau profil lain yang masih kosong, lalu pulihkan file backup di sana (PIN ikut terhapus bila kamu tidak mengatur ulang). Karena itu simpan backup dan catat PIN-mu.

## Memperbarui aplikasi

Ganti file di tempat hosting dengan versi baru. Data tidak ikut terhapus karena tersimpan di perangkat. Tutup dan buka aplikasi dua kali agar versi baru aktif.
